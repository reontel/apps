<?php


$name       = @trim(stripslashes($_POST['name'])); 
$from       = @trim(stripslashes($_POST['email'])); 
$subject    = @trim(stripslashes($_POST['subject'])); 
$message    = @trim(stripslashes($_POST['message'])); 
$to   		= 'sales@reontel.com';//replace with your email

// prepare email body text
$Body = "";
$Body .= "Name: ";
$Body .= $name;
$Body .= "\n";
$Body .= "Email: ";
$Body .= $from;
$Body .= "\n";
$Body .= "Subject: ";
$Body .= $subject;
$Body .= "\n";
$Body .= "Message: ";
$Body .= $message;
$Body .= "\n";

/*
$headers   = array();
$headers[] = "MIME-Version: 1.0";
$headers[] = "Content-type: text/plain; charset=iso-8859-1";
$headers[] = "From: {$name} <{$from}>";
$headers[] = "Reply-To: <{$from}>";
$headers[] = "Subject: {$subject}";
$headers[] = "X-Mailer: PHP/".phpversion();

mail($to, $subject, $message, $headers);
*/

// send email
$headers = 'From: Reon Technologies  <info@reontel.com>' . "\r\n" .
	'Reply-To: Reon Technologies  <info@reontel.com>' . "\r\n" .
	'X-Mailer: PHP/' . phpversion();

$success = mail($to, $subject, $Body, $headers);

// Save to Contact XML File
$contactFile = "xml/contact.xml";

$xml = new DOMDocument();

$nodeID=1;
if(file_exists($contactFile)) {
	$xml->load($contactFile);
	$nodes = $xml->getElementsByTagName('Name') ;
	$nodeID = $nodes->length;
	$nodeID++;
	$root_node = $xml->documentElement;
}
else {
	$root_node = $xml->createElement("contacts");
}

$xml_contact = $xml->createElement("contact");
$xml_id = $xml->createElement("id",$nodeID);
$xml_name = $xml->createElement("Name",$name);
$xml_email = $xml->createElement("Email",$from);
$xml_sub = $xml->createElement("Subject",$subject);
$xml_message = $xml->createElement("Message",$message);
$xml_date = $xml->createElement("Date",date("d-m-Y H:i:s"));

$xml_contact->appendChild( $xml_id );
$xml_contact->appendChild( $xml_name );
$xml_contact->appendChild( $xml_email );
$xml_contact->appendChild( $xml_sub );
$xml_contact->appendChild( $xml_message );
$xml_contact->appendChild( $xml_date );

$root_node->appendChild( $xml_contact );

$xml->appendChild( $root_node );

$xml->save($contactFile);




die;